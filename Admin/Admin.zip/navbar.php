<?php
    echo '<nav class="navbar navbar-dark bg-danger fixed-top">
    <div class="container-fluid">
      <a class="navbar-brand" href="./"><img src="./assets/img/avatars/logo.png" style="margin:inherit" alt="" width="30" height="24"><span>Jaipurplaza</span></a>
    </div>
  </nav>';
?>