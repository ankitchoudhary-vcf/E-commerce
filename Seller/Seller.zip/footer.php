<?php
echo '<footer class="footer mt-auto py-3 bg-dark" style="position: absolute; left: 0; right: 0;">
      <div class="container">
        <div class="row m-4">
        <div class="col-12">
        <span class="h3 text-white">About Us :- </span><br><br>
        <span class="text-white"><strong>Jaipur’s Favourite Online Shopping Platform</strong><br><br>
        Jaipurplaza.com is Jaipur’s Favourite Online Shopping Platform. We deliver products related to mobile and computer accessories such as tempered glass, back cover, memory card, headphone, earphone, charger, mouse, keyboard, pen drive and much more at affordable price with home delivery.
        </span>
        </div>
        </div>
        <div class="row m-4">
          <div class="col-sm-6">
          <span class="text-white h3">Contact Us :- </span><br><br>
            <span class="text-white"><strong>Registered Office Address :</strong><br>Raisar Plaza, Indira Market,<br>Near Ajmeri Gate,<br>Jaipur,
              Rajasthan, India(302001)<br><br><strong>Call : </strong>(+91 7340402736)<br><strong>WhatsApp : </strong>(+91
              7340402736)</span>
          </div>
          <div class="col-sm-6">
            <span class="text-white h3">Social media links :- </span><br><br>
            <div style="font-size:30px;">
              <a href=" https://www.facebook.com/jprplaza/" class="fa fa-facebook" style="text-decoration: none; color: white; background: #5851DB; height: 40px; width: 40px; padding: 6px; text-align: center;"></a>
              <a href="https://www.instagram.com/jaipurplaza" class="fa fa-instagram" style="text-decoration: none; color: white; background-image: linear-gradient(45deg, #405DE6,#5851DB,#833AB4,#C13584,#E1306C,#FD1D1D,#F56040,#F77737,#FCAF45, #FFDC80); height: 40px; width: 40px; padding: 6px; text-align: center;"></a>
              <a href="https://www.raisarplaza.online/" class="fa fa-google" style="text-decoration: none; color: white; background-image: linear-gradient(90deg, #4285F4,#BB001B,#EA4335,#FBBC05,#34A853); height: 40px; width: 40px; padding: 6px; text-align: center;"></a>
              <a href="https://www.youtube.com/channel/UCSVgbYzkrYHvCsm1dYOAacA/" class="fa fa-youtube" style="text-decoration: none; color: white; background: #FF0000; height: 40px; width: 40px; padding: 6px; text-align: center;"></a>
            </div>
          </div>
        </div>
      </div>
      <hr style="color:white">
      <div class="container">
        <center>
          <span class="text-muted">© 2020-2021 Jaipurplaza.com</span>
        </center>
      </div>
    </footer>';
?>
